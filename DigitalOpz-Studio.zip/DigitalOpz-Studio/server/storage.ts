import { type User, type InsertUser, type GeneratedImage, type InsertGeneratedImage, type GenerationJob, type InsertGenerationJob, type Template, type InsertTemplate } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Generated images methods
  getGeneratedImage(id: string): Promise<GeneratedImage | undefined>;
  getGeneratedImages(limit?: number, offset?: number): Promise<GeneratedImage[]>;
  getUserGeneratedImages(userId: string, limit?: number, offset?: number): Promise<GeneratedImage[]>;
  createGeneratedImage(image: InsertGeneratedImage): Promise<GeneratedImage>;
  deleteGeneratedImage(id: string): Promise<boolean>;
  
  // Generation jobs methods
  getGenerationJob(id: string): Promise<GenerationJob | undefined>;
  getUserGenerationJobs(userId: string): Promise<GenerationJob[]>;
  createGenerationJob(job: InsertGenerationJob): Promise<GenerationJob>;
  updateGenerationJob(id: string, updates: Partial<GenerationJob>): Promise<GenerationJob | undefined>;
  
  // Templates methods
  getTemplate(id: string): Promise<Template | undefined>;
  getTemplates(category?: string, limit?: number, offset?: number): Promise<Template[]>;
  createTemplate(template: InsertTemplate): Promise<Template>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private generatedImages: Map<string, GeneratedImage>;
  private generationJobs: Map<string, GenerationJob>;
  private templates: Map<string, Template>;

  constructor() {
    this.users = new Map();
    this.generatedImages = new Map();
    this.generationJobs = new Map();
    this.templates = new Map();
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Create sample user
    const sampleUser: User = {
      id: "user-1",
      username: "demo_user",
      email: "demo@example.com",
      credits: -1, // Unlimited
      isPro: true, // Everyone is pro
      createdAt: new Date(),
    };
    this.users.set(sampleUser.id, sampleUser);

    // Create sample templates
    const sampleTemplates: Template[] = [
      {
        id: "template-1",
        name: "Fantasy Portrait",
        description: "Create mystical character portraits",
        prompt: "A mystical character portrait with ethereal lighting, fantasy art style, highly detailed",
        negativePrompt: "blurry, low quality, distorted",
        model: "ideogram-3.0",
        style: "realistic",
        aspectRatio: "1:1",
        steps: 30,
        cfgScale: 8,
        thumbnailUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400",
        category: "Character",
        isPublic: true,
        createdBy: sampleUser.id,
        createdAt: new Date(),
      },
      {
        id: "template-2",
        name: "Logo Design",
        description: "Professional logo generation",
        prompt: "Modern minimalist logo design, clean lines, professional branding",
        negativePrompt: "cluttered, complex, low resolution",
        model: "ideogram-3.0",
        style: "design",
        aspectRatio: "1:1",
        steps: 25,
        cfgScale: 7,
        thumbnailUrl: "https://images.unsplash.com/photo-1561070791-2526d30994b5?w=400",
        category: "Branding",
        isPublic: true,
        createdBy: sampleUser.id,
        createdAt: new Date(),
      },
    ];

    sampleTemplates.forEach(template => this.templates.set(template.id, template));
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      credits: -1, // Unlimited
      isPro: true, // Everyone is pro
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  // Generated images methods
  async getGeneratedImage(id: string): Promise<GeneratedImage | undefined> {
    return this.generatedImages.get(id);
  }

  async getGeneratedImages(limit = 20, offset = 0): Promise<GeneratedImage[]> {
    const images = Array.from(this.generatedImages.values())
      .filter(img => img.isPublic)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime())
      .slice(offset, offset + limit);
    return images;
  }

  async getUserGeneratedImages(userId: string, limit = 20, offset = 0): Promise<GeneratedImage[]> {
    const images = Array.from(this.generatedImages.values())
      .filter(img => img.userId === userId)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime())
      .slice(offset, offset + limit);
    return images;
  }

  async createGeneratedImage(insertImage: InsertGeneratedImage): Promise<GeneratedImage> {
    const id = randomUUID();
    const image: GeneratedImage = { 
      ...insertImage, 
      id,
      createdAt: new Date(),
    };
    this.generatedImages.set(id, image);
    return image;
  }

  async deleteGeneratedImage(id: string): Promise<boolean> {
    return this.generatedImages.delete(id);
  }

  // Generation jobs methods
  async getGenerationJob(id: string): Promise<GenerationJob | undefined> {
    return this.generationJobs.get(id);
  }

  async getUserGenerationJobs(userId: string): Promise<GenerationJob[]> {
    return Array.from(this.generationJobs.values())
      .filter(job => job.userId === userId)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async createGenerationJob(insertJob: InsertGenerationJob): Promise<GenerationJob> {
    const id = randomUUID();
    const job: GenerationJob = { 
      ...insertJob,
      id,
      status: "pending",
      progress: 0,
      estimatedTime: 30 + Math.floor(Math.random() * 60), // 30-90 seconds
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.generationJobs.set(id, job);
    return job;
  }

  async updateGenerationJob(id: string, updates: Partial<GenerationJob>): Promise<GenerationJob | undefined> {
    const job = this.generationJobs.get(id);
    if (!job) return undefined;

    const updatedJob: GenerationJob = { 
      ...job, 
      ...updates, 
      updatedAt: new Date() 
    };
    this.generationJobs.set(id, updatedJob);
    return updatedJob;
  }

  // Templates methods
  async getTemplate(id: string): Promise<Template | undefined> {
    return this.templates.get(id);
  }

  async getTemplates(category?: string, limit = 20, offset = 0): Promise<Template[]> {
    let templates = Array.from(this.templates.values())
      .filter(t => t.isPublic);
    
    if (category) {
      templates = templates.filter(t => t.category === category);
    }

    return templates
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime())
      .slice(offset, offset + limit);
  }

  async createTemplate(insertTemplate: InsertTemplate): Promise<Template> {
    const id = randomUUID();
    const template: Template = { 
      ...insertTemplate, 
      id,
      createdAt: new Date(),
    };
    this.templates.set(id, template);
    return template;
  }
}

export const storage = new MemStorage();
