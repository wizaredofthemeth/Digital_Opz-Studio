import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateImageSchema, type GenerateImageRequest, type GenerationJob, type GeneratedImage } from "@shared/schema";
import { randomUUID } from "crypto";

// Mock image generation service
class MockImageGenerationService {
  private static readonly SAMPLE_IMAGES = [
    "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=800",
    "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=800",
    "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800",
    "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800",
    "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800",
    "https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?w=800",
    "https://images.unsplash.com/photo-1501594907352-04cda38ebc29?w=800",
    "https://images.unsplash.com/photo-1542223189-67a03fa0f0c4?w=800",
  ];

  static async simulateGeneration(request: GenerateImageRequest, jobId: string): Promise<void> {
    const job = await storage.getGenerationJob(jobId);
    if (!job) return;

    // Simulate progressive updates
    const updateIntervals = [10, 30, 60, 85, 100];
    
    for (const progress of updateIntervals) {
      await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
      
      await storage.updateGenerationJob(jobId, {
        status: progress === 100 ? "completed" : "processing",
        progress,
      });

      if (progress === 100) {
        // Generate the final image
        const [width, height] = this.getAspectRatioDimensions(request.aspectRatio);
        const imageUrl = this.SAMPLE_IMAGES[Math.floor(Math.random() * this.SAMPLE_IMAGES.length)];
        
        const generatedImage: Omit<GeneratedImage, "id" | "createdAt"> = {
          userId: job.userId,
          prompt: request.prompt,
          negativePrompt: request.negativePrompt || null,
          model: request.model,
          style: request.style,
          aspectRatio: request.aspectRatio,
          steps: request.steps || 25,
          cfgScale: request.cfgScale || 7,
          seed: request.seed || Math.floor(Math.random() * 1000000),
          imageUrl,
          thumbnailUrl: imageUrl,
          width,
          height,
          isPublic: true,
          colorPalette: request.colorPalette || null,
          generationTime: 15 + Math.floor(Math.random() * 45),
        };

        const image = await storage.createGeneratedImage(generatedImage);
        await storage.updateGenerationJob(jobId, {
          resultImageId: image.id,
        });
      }
    }
  }

  private static getAspectRatioDimensions(aspectRatio: string): [number, number] {
    const ratioMap: Record<string, [number, number]> = {
      "1:1": [800, 800],
      "16:9": [1024, 576],
      "9:16": [576, 1024],
      "3:1": [1200, 400],
      "1:3": [400, 1200],
      "4:3": [800, 600],
    };
    return ratioMap[aspectRatio] || [800, 800];
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Get current user (mock for demo)
  app.get("/api/user/current", async (req, res) => {
    const user = await storage.getUser("user-1");
    res.json(user);
  });

  // Generate image
  app.post("/api/generate", async (req, res) => {
    try {
      const validatedRequest = generateImageSchema.parse(req.body);
      
      // Create generation job
      const job = await storage.createGenerationJob({
        userId: "user-1", // Mock user ID
        ...validatedRequest,
      });

      // Start generation in background
      MockImageGenerationService.simulateGeneration(validatedRequest, job.id);

      res.json({ jobId: job.id });
    } catch (error) {
      res.status(400).json({ error: "Invalid generation request" });
    }
  });

  // Get generation job status
  app.get("/api/jobs/:jobId", async (req, res) => {
    const job = await storage.getGenerationJob(req.params.jobId);
    if (!job) {
      return res.status(404).json({ error: "Job not found" });
    }
    res.json(job);
  });

  // Get user's generation jobs
  app.get("/api/user/jobs", async (req, res) => {
    const jobs = await storage.getUserGenerationJobs("user-1");
    res.json(jobs);
  });

  // Get generated images (public gallery)
  app.get("/api/images", async (req, res) => {
    const limit = parseInt(req.query.limit as string) || 20;
    const offset = parseInt(req.query.offset as string) || 0;
    
    const images = await storage.getGeneratedImages(limit, offset);
    res.json(images);
  });

  // Get user's generated images
  app.get("/api/user/images", async (req, res) => {
    const limit = parseInt(req.query.limit as string) || 20;
    const offset = parseInt(req.query.offset as string) || 0;
    
    const images = await storage.getUserGeneratedImages("user-1", limit, offset);
    res.json(images);
  });

  // Get single generated image
  app.get("/api/images/:imageId", async (req, res) => {
    const image = await storage.getGeneratedImage(req.params.imageId);
    if (!image) {
      return res.status(404).json({ error: "Image not found" });
    }
    res.json(image);
  });

  // Delete generated image
  app.delete("/api/images/:imageId", async (req, res) => {
    const success = await storage.deleteGeneratedImage(req.params.imageId);
    if (!success) {
      return res.status(404).json({ error: "Image not found" });
    }
    res.json({ success: true });
  });

  // Get templates
  app.get("/api/templates", async (req, res) => {
    const category = req.query.category as string;
    const limit = parseInt(req.query.limit as string) || 20;
    const offset = parseInt(req.query.offset as string) || 0;
    
    const templates = await storage.getTemplates(category, limit, offset);
    res.json(templates);
  });

  // Get single template
  app.get("/api/templates/:templateId", async (req, res) => {
    const template = await storage.getTemplate(req.params.templateId);
    if (!template) {
      return res.status(404).json({ error: "Template not found" });
    }
    res.json(template);
  });

  // Magic prompt enhancement
  app.post("/api/enhance-prompt", async (req, res) => {
    const { prompt } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: "Prompt is required" });
    }

    // Mock enhancement - add descriptive elements
    const enhancements = [
      "highly detailed, cinematic lighting, 8K resolution",
      "professional photography, studio quality",
      "vibrant colors, sharp focus, masterpiece",
      "photorealistic, ultra-detailed, award-winning",
      "dramatic lighting, perfect composition",
      "hyper-realistic, premium quality, trending on artstation",
    ];

    const enhancement = enhancements[Math.floor(Math.random() * enhancements.length)];
    const enhancedPrompt = `${prompt}, ${enhancement}`;

    res.json({ enhancedPrompt });
  });

  // Image description generation
  app.post("/api/describe-image", async (req, res) => {
    const { imageUrl } = req.body;
    if (!imageUrl) {
      return res.status(400).json({ error: "Image URL is required" });
    }

    // Mock description
    const descriptions = [
      "A breathtaking landscape with mountains reflected in a crystal-clear lake at sunset",
      "An ethereal fantasy character with flowing robes and mystical aura",
      "A modern architectural masterpiece with sleek lines and glass surfaces",
      "A vibrant digital art piece featuring abstract geometric patterns",
      "A photorealistic portrait with dramatic lighting and perfect composition",
    ];

    const description = descriptions[Math.floor(Math.random() * descriptions.length)];

    res.json({ description });
  });

  const httpServer = createServer(app);
  return httpServer;
}
