import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email"),
  credits: integer("credits").default(-1), // -1 means unlimited
  isPro: boolean("is_pro").default(true), // Everyone is pro by default
  createdAt: timestamp("created_at").defaultNow(),
});

export const generatedImages = pgTable("generated_images", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  prompt: text("prompt").notNull(),
  negativePrompt: text("negative_prompt"),
  model: text("model").notNull(),
  style: text("style").notNull(),
  aspectRatio: text("aspect_ratio").notNull(),
  steps: integer("steps").default(25),
  cfgScale: integer("cfg_scale").default(7),
  seed: integer("seed"),
  imageUrl: text("image_url").notNull(),
  thumbnailUrl: text("thumbnail_url"),
  width: integer("width").notNull(),
  height: integer("height").notNull(),
  isPublic: boolean("is_public").default(true),
  colorPalette: jsonb("color_palette"),
  generationTime: integer("generation_time"), // in seconds
  createdAt: timestamp("created_at").defaultNow(),
});

export const generationJobs = pgTable("generation_jobs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  prompt: text("prompt").notNull(),
  negativePrompt: text("negative_prompt"),
  model: text("model").notNull(),
  style: text("style").notNull(),
  aspectRatio: text("aspect_ratio").notNull(),
  steps: integer("steps").default(25),
  cfgScale: integer("cfg_scale").default(7),
  seed: integer("seed"),
  status: text("status").notNull().default("pending"), // pending, processing, completed, failed
  progress: integer("progress").default(0),
  estimatedTime: integer("estimated_time"),
  resultImageId: varchar("result_image_id").references(() => generatedImages.id),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const templates = pgTable("templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  prompt: text("prompt").notNull(),
  negativePrompt: text("negative_prompt"),
  model: text("model").notNull(),
  style: text("style").notNull(),
  aspectRatio: text("aspect_ratio").notNull(),
  steps: integer("steps").default(25),
  cfgScale: integer("cfg_scale").default(7),
  thumbnailUrl: text("thumbnail_url"),
  category: text("category").notNull(),
  isPublic: boolean("is_public").default(true),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
});

export const insertGeneratedImageSchema = createInsertSchema(generatedImages).omit({
  id: true,
  createdAt: true,
});

export const insertGenerationJobSchema = createInsertSchema(generationJobs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  status: true,
  progress: true,
  resultImageId: true,
  errorMessage: true,
});

export const insertTemplateSchema = createInsertSchema(templates).omit({
  id: true,
  createdAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertGeneratedImage = z.infer<typeof insertGeneratedImageSchema>;
export type GeneratedImage = typeof generatedImages.$inferSelect;

export type InsertGenerationJob = z.infer<typeof insertGenerationJobSchema>;
export type GenerationJob = typeof generationJobs.$inferSelect;

export type InsertTemplate = z.infer<typeof insertTemplateSchema>;
export type Template = typeof templates.$inferSelect;

// Additional validation schemas
export const generateImageSchema = z.object({
  prompt: z.string().min(1, "Prompt is required").max(2000, "Prompt too long"),
  negativePrompt: z.string().optional(),
  model: z.enum(["ideogram-1.0", "ideogram-2.0", "ideogram-3.0", "flux-pro", "sdxl", "sdxl-lightning", "custom"]),
  style: z.enum(["realistic", "design", "3d", "anime", "nsfw", "adult", "erotic"]),
  aspectRatio: z.enum(["1:1", "16:9", "9:16", "3:1", "1:3", "4:3"]),
  steps: z.number().min(10).max(50).default(25),
  cfgScale: z.number().min(1).max(20).default(7),
  seed: z.number().optional(),
  colorPalette: z.array(z.string()).optional(),
  allowNsfw: z.boolean().default(true),
  contentFilter: z.enum(["none", "mild", "strict"]).default("none"),
});

export type GenerateImageRequest = z.infer<typeof generateImageSchema>;
