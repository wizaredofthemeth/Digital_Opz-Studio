import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Gallery from "@/pages/gallery";
import Navbar from "@/components/navbar";

function Router() {
  return (
    <div className="min-h-screen bg-cyber-bg text-primary font-sans relative overflow-hidden">
      {/* Spectacular Rainbow Splash Background */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute inset-0 splash-neon"></div>
        <div className="absolute inset-0 smoke-bg"></div>
        <div className="absolute inset-0 gringy-texture"></div>
        
        {/* Animated neon streams */}
        <div className="absolute top-10 left-10 w-2 h-20 gradient-rainbow animate-data-stream opacity-60" style={{animationDelay: '0s'}}></div>
        <div className="absolute top-20 left-40 w-1 h-16 gradient-rainbow animate-data-stream opacity-60" style={{animationDelay: '2s'}}></div>
        <div className="absolute top-0 right-20 w-1 h-12 gradient-rainbow animate-data-stream opacity-60" style={{animationDelay: '4s'}}></div>
        <div className="absolute top-32 right-60 w-2 h-24 gradient-rainbow animate-data-stream opacity-60" style={{animationDelay: '6s'}}></div>
        
        {/* Electric surge effects */}
        <div className="absolute top-1/4 left-1/3 w-4 h-4 rounded-full animate-electric-surge opacity-40"></div>
        <div className="absolute bottom-1/3 right-1/4 w-6 h-6 rounded-full animate-electric-surge opacity-40" style={{animationDelay: '3s'}}></div>
        <div className="absolute top-2/3 left-2/3 w-3 h-3 rounded-full animate-electric-surge opacity-40" style={{animationDelay: '1.5s'}}></div>
      </div>
      
      <Navbar />
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/gallery" component={Gallery} />
        <Route component={NotFound} />
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
