import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { generateImageSchema, type GenerateImageRequest, type Template } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { 
  Sparkles, 
  Wand2, 
  Settings, 
  Palette, 
  Square, 
  Zap, 
  Crown,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import { cn } from "@/lib/utils";

interface GenerationControlsProps {
  onGenerate: (request: GenerateImageRequest) => void;
  isGenerating: boolean;
}

const AI_MODELS = [
  { value: "ideogram-3.0", label: "Ideogram 3.0", badge: "LATEST", premium: false },
  { value: "ideogram-2.0", label: "Ideogram 2.0", badge: "STABLE", premium: false },
  { value: "ideogram-1.0", label: "Ideogram 1.0", badge: "CLASSIC", premium: false },
  { value: "flux-pro", label: "FLUX Pro", badge: "FAST", premium: false },
  { value: "sdxl", label: "Stable Diffusion XL", badge: "QUALITY", premium: false },
  { value: "sdxl-lightning", label: "SDXL Lightning", badge: "SPEED", premium: false },
  { value: "custom", label: "Custom Model", badge: "BETA", premium: false },
];

const GENERATION_STYLES = [
  { value: "realistic", label: "Realistic", icon: "📷" },
  { value: "design", label: "Design", icon: "🎨" },
  { value: "3d", label: "3D Render", icon: "🎭" },
  { value: "anime", label: "Anime", icon: "🌸" },
  { value: "nsfw", label: "NSFW", icon: "🔥" },
  { value: "adult", label: "Adult", icon: "💋" },
  { value: "erotic", label: "Erotic", icon: "🌹" },
];

const ASPECT_RATIOS = [
  { value: "1:1", label: "Square", dimensions: "1:1", icon: "⬜" },
  { value: "16:9", label: "Landscape", dimensions: "16:9", icon: "📱" },
  { value: "9:16", label: "Portrait", dimensions: "9:16", icon: "📱" },
  { value: "3:1", label: "Ultra-wide", dimensions: "3:1", icon: "📏" },
  { value: "1:3", label: "Ultra-tall", dimensions: "1:3", icon: "📏" },
  { value: "4:3", label: "Classic", dimensions: "4:3", icon: "🖼️" },
];

const COLOR_PALETTE_PRESETS = [
  { name: "Vibrant", colors: ["#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4", "#FFEAA7"] },
  { name: "Monochrome", colors: ["#2C2C2C", "#5A5A5A", "#8A8A8A", "#B8B8B8", "#E6E6E6"] },
  { name: "Sunset", colors: ["#FF9068", "#FF6B9D", "#C44569", "#F8B500", "#FFD93D"] },
  { name: "Ocean", colors: ["#0077BE", "#00A8CC", "#7FCDFF", "#B8E6FF", "#E8F4FD"] },
  { name: "Forest", colors: ["#2E8B57", "#32CD32", "#90EE90", "#228B22", "#006400"] },
];

export default function GenerationControls({ onGenerate, isGenerating }: GenerationControlsProps) {
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [selectedColorPalette, setSelectedColorPalette] = useState<string[]>([]);

  const form = useForm<GenerateImageRequest>({
    resolver: zodResolver(generateImageSchema),
    defaultValues: {
      prompt: "",
      negativePrompt: "",
      model: "ideogram-3.0",
      style: "realistic",
      aspectRatio: "1:1",
      steps: 25,
      cfgScale: 7,
      colorPalette: [],
      allowNsfw: true,
      contentFilter: "none",
    },
  });

  // Get templates
  const { data: templates = [] } = useQuery<Template[]>({
    queryKey: ["/api/templates"],
  });

  // Enhance prompt mutation
  const enhancePromptMutation = useMutation({
    mutationFn: async (prompt: string) => {
      const res = await apiRequest("POST", "/api/enhance-prompt", { prompt });
      return res.json();
    },
    onSuccess: (data) => {
      form.setValue("prompt", data.enhancedPrompt);
    },
  });

  const handleEnhancePrompt = () => {
    const currentPrompt = form.getValues("prompt");
    if (currentPrompt.trim()) {
      enhancePromptMutation.mutate(currentPrompt);
    }
  };

  const loadTemplate = (template: Template) => {
    form.setValue("prompt", template.prompt);
    form.setValue("negativePrompt", template.negativePrompt || "");
    form.setValue("model", template.model as any);
    form.setValue("style", template.style as any);
    form.setValue("aspectRatio", template.aspectRatio as any);
    form.setValue("steps", template.steps || 25);
    form.setValue("cfgScale", template.cfgScale || 7);
  };

  const onSubmit = (data: GenerateImageRequest) => {
    onGenerate({
      ...data,
      colorPalette: selectedColorPalette.length > 0 ? selectedColorPalette : undefined,
    });
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-cyber-border smoke-bg">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold font-mono tracking-wider animate-neon-rainbow-glow">GENERATION STUDIO</h2>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="border-cyber-border cyber-glass hover:neon-glow-cyan transition-all duration-300"
          >
            <Settings className="w-4 h-4 mr-2 animate-neon-flicker" />
            {showAdvanced ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </Button>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            {/* Model Selection */}
            <FormField
              control={form.control}
              name="model"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-mono tracking-wide neon-text-cyan">AI MODEL</FormLabel>
                  <FormControl>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <SelectTrigger className="bg-cyber-card cyber-glass border-cyber-border text-primary font-mono">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-cyber-card cyber-glass border-cyber-border">
                        {AI_MODELS.map((model) => (
                          <SelectItem key={model.value} value={model.value} className="hover:neon-glow-cyan transition-all duration-300">
                            <div className="flex items-center justify-between w-full">
                              <span className="font-mono">{model.label}</span>
                              <div className="flex items-center space-x-1 ml-2">
                                <Badge variant="outline" className="text-xs font-mono neon-glow-pink border-cyber-border">
                                  {model.badge}
                                </Badge>
                              </div>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormControl>
                </FormItem>
              )}
            />

            {/* Style Selection */}
            <FormField
              control={form.control}
              name="style"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-mono tracking-wide neon-text-pink">GENERATION STYLE</FormLabel>
                  <FormControl>
                    <div className="grid grid-cols-2 gap-2">
                      {GENERATION_STYLES.map((style) => (
                        <Button
                          key={style.value}
                          type="button"
                          variant={field.value === style.value ? "default" : "outline"}
                          className={cn(
                            "justify-start text-xs font-mono transition-all duration-300",
                            field.value === style.value
                              ? "gradient-cyber text-black animate-rainbow-shift"
                              : "bg-cyber-card cyber-glass border-cyber-border text-muted-foreground hover:neon-glow-yellow"
                          )}
                          onClick={() => field.onChange(style.value)}
                        >
                          <span className="mr-2">{style.icon}</span>
                          {style.label.toUpperCase()}
                        </Button>
                      ))}
                    </div>
                  </FormControl>
                </FormItem>
              )}
            />
          </form>
        </Form>
      </div>

      {/* Prompt Section */}
      <div className="p-6 border-b border-cyber-border gringy-texture">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <FormField
              control={form.control}
              name="prompt"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-mono tracking-wide neon-text-yellow">PROMPT</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Textarea
                        {...field}
                        placeholder="DESCRIBE YOUR VISION IN DETAIL..."
                        className="bg-cyber-card cyber-glass border-cyber-border text-primary placeholder-muted-foreground resize-none h-24 pr-20 font-mono"
                      />
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        className="absolute bottom-2 right-2 neon-text-green hover:neon-glow-green transition-all duration-300"
                        onClick={handleEnhancePrompt}
                        disabled={enhancePromptMutation.isPending}
                      >
                        <Wand2 className="w-4 h-4 mr-1 animate-neon-flicker" />
                        ENHANCE
                      </Button>
                    </div>
                  </FormControl>
                </FormItem>
              )}
            />

            {/* Negative Prompt */}
            <FormField
              control={form.control}
              name="negativePrompt"
              render={({ field }) => (
                <FormItem className="mt-4">
                  <FormLabel className="font-mono tracking-wide neon-text-red">NEGATIVE PROMPT</FormLabel>
                  <FormControl>
                    <Textarea
                      {...field}
                      placeholder="WHAT TO AVOID IN THE IMAGE..."
                      className="bg-cyber-card cyber-glass border-cyber-border text-primary placeholder-muted-foreground resize-none h-16 font-mono"
                    />
                  </FormControl>
                </FormItem>
              )}
            />
          </form>
        </Form>
      </div>

      {/* Advanced Settings */}
      <div className="flex-1 overflow-y-auto">
        {showAdvanced && (
          <div className="p-6 space-y-6 gringy-texture">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)}>
                {/* NSFW Controls */}
                <FormField
                  control={form.control}
                  name="allowNsfw"
                  render={({ field }) => (
                    <FormItem className="mb-6">
                      <div className="flex items-center justify-between">
                        <FormLabel className="font-mono tracking-wide neon-text-pink">NSFW CONTENT ALLOWED</FormLabel>
                        <FormControl>
                          <Button
                            type="button"
                            variant={field.value ? "default" : "outline"}
                            size="sm"
                            className={cn(
                              "font-mono transition-all duration-300",
                              field.value
                                ? "gradient-cyber text-black animate-rainbow-shift"
                                : "bg-cyber-card cyber-glass border-cyber-border text-muted-foreground hover:neon-glow-pink"
                            )}
                            onClick={() => field.onChange(!field.value)}
                          >
                            {field.value ? "ENABLED 🔥" : "DISABLED"}
                          </Button>
                        </FormControl>
                      </div>
                    </FormItem>
                  )}
                />

                {/* Content Filter */}
                <FormField
                  control={form.control}
                  name="contentFilter"
                  render={({ field }) => (
                    <FormItem className="mb-6">
                      <FormLabel className="font-mono tracking-wide neon-text-cyan">CONTENT FILTER</FormLabel>
                      <FormControl>
                        <div className="grid grid-cols-3 gap-2">
                          {[
                            { value: "none", label: "NONE", desc: "No restrictions" },
                            { value: "mild", label: "MILD", desc: "Basic filtering" },
                            { value: "strict", label: "STRICT", desc: "Heavy filtering" }
                          ].map((filter) => (
                            <Button
                              key={filter.value}
                              type="button"
                              variant={field.value === filter.value ? "default" : "outline"}
                              className={cn(
                                "flex flex-col items-center p-3 h-auto font-mono transition-all duration-300",
                                field.value === filter.value
                                  ? "gradient-cyber text-black animate-rainbow-shift"
                                  : "bg-cyber-card cyber-glass border-cyber-border text-muted-foreground hover:neon-glow-cyan"
                              )}
                              onClick={() => field.onChange(filter.value)}
                            >
                              <span className="font-bold">{filter.label}</span>
                              <span className="text-xs opacity-70">{filter.desc}</span>
                            </Button>
                          ))}
                        </div>
                      </FormControl>
                    </FormItem>
                  )}
                />

                {/* Aspect Ratio */}
                <FormField
                  control={form.control}
                  name="aspectRatio"
                  render={({ field }) => (
                    <FormItem className="mb-6">
                      <FormLabel className="font-mono tracking-wide neon-text-yellow flex items-center">
                        <Square className="w-4 h-4 mr-2 animate-neon-flicker" />
                        ASPECT RATIO
                      </FormLabel>
                      <FormControl>
                        <div className="grid grid-cols-3 gap-2">
                          {ASPECT_RATIOS.map((ratio) => (
                            <Button
                              key={ratio.value}
                              type="button"
                              variant={field.value === ratio.value ? "default" : "outline"}
                              className={cn(
                                "flex flex-col items-center p-3 h-auto transition-colors",
                                field.value === ratio.value
                                  ? "bg-primary border-primary text-white"
                                  : "bg-dark-card border-dark-border text-gray-300 hover:border-primary"
                              )}
                              onClick={() => field.onChange(ratio.value)}
                            >
                              <span className="text-lg mb-1">{ratio.icon}</span>
                              <span className="text-xs font-medium">{ratio.dimensions}</span>
                            </Button>
                          ))}
                        </div>
                      </FormControl>
                    </FormItem>
                  )}
                />

                {/* Quality Settings */}
                <div className="space-y-4 mb-6">
                  <h3 className="text-sm font-medium text-gray-300 flex items-center">
                    <Zap className="w-4 h-4 mr-2" />
                    Quality Settings
                  </h3>

                  <FormField
                    control={form.control}
                    name="steps"
                    render={({ field }) => (
                      <FormItem>
                        <div className="flex justify-between items-center">
                          <FormLabel className="text-xs text-gray-400">Steps</FormLabel>
                          <span className="text-xs text-gray-400">{field.value}</span>
                        </div>
                        <FormControl>
                          <Slider
                            value={[field.value]}
                            onValueChange={(value) => field.onChange(value[0])}
                            max={50}
                            min={10}
                            step={5}
                            className="w-full"
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="cfgScale"
                    render={({ field }) => (
                      <FormItem>
                        <div className="flex justify-between items-center">
                          <FormLabel className="text-xs text-gray-400">CFG Scale</FormLabel>
                          <span className="text-xs text-gray-400">{field.value}</span>
                        </div>
                        <FormControl>
                          <Slider
                            value={[field.value]}
                            onValueChange={(value) => field.onChange(value[0])}
                            max={20}
                            min={1}
                            step={0.5}
                            className="w-full"
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>

                {/* Color Palette */}
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-300 flex items-center mb-3">
                    <Palette className="w-4 h-4 mr-2" />
                    Brand Color Palette
                  </h3>
                  <div className="space-y-2">
                    {COLOR_PALETTE_PRESETS.map((preset) => (
                      <Button
                        key={preset.name}
                        type="button"
                        variant="outline"
                        className={cn(
                          "w-full justify-start bg-dark-card border-dark-border text-gray-300 hover:border-primary",
                          selectedColorPalette === preset.colors && "border-primary bg-primary/10"
                        )}
                        onClick={() => setSelectedColorPalette(preset.colors)}
                      >
                        <div className="flex items-center space-x-3">
                          <div className="flex space-x-1">
                            {preset.colors.slice(0, 4).map((color, i) => (
                              <div
                                key={i}
                                className="w-4 h-4 rounded-full border border-gray-600"
                                style={{ backgroundColor: color }}
                              />
                            ))}
                          </div>
                          <span className="text-sm">{preset.name}</span>
                        </div>
                      </Button>
                    ))}
                  </div>
                </div>
              </form>
            </Form>
          </div>
        )}

        {/* Templates Section */}
        {templates.length > 0 && (
          <div className="p-6 border-t border-dark-border">
            <h3 className="text-sm font-medium text-gray-300 mb-3 flex items-center">
              <Sparkles className="w-4 h-4 mr-2" />
              Quick Templates
            </h3>
            <div className="space-y-2">
              {templates.slice(0, 3).map((template) => (
                <Button
                  key={template.id}
                  type="button"
                  variant="outline"
                  className="w-full justify-start bg-dark-card border-dark-border text-gray-300 hover:border-primary text-left p-3 h-auto"
                  onClick={() => loadTemplate(template)}
                >
                  <div className="flex flex-col items-start">
                    <span className="font-medium text-sm">{template.name}</span>
                    <span className="text-xs text-gray-500 truncate w-full">
                      {template.description}
                    </span>
                  </div>
                </Button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Generate Button */}
      <div className="p-6 border-t border-dark-border">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <Button
              type="submit"
              disabled={isGenerating}
              className="w-full bg-primary hover:bg-primary/90 text-white font-medium py-3 text-base"
            >
              {isGenerating ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-2" />
                  Generate Image
                </>
              )}
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
}
