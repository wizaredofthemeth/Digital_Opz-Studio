import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { type GenerationJob, type GeneratedImage } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, Clock, Sparkles, Zap, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface GenerationProgressProps {
  jobId: string;
  onComplete: (image: GeneratedImage) => void;
}

const GENERATION_STEPS = [
  { id: 1, name: "Initializing", progress: 10 },
  { id: 2, name: "Processing prompt", progress: 30 },
  { id: 3, name: "Generating image", progress: 60 },
  { id: 4, name: "Enhancing details", progress: 85 },
  { id: 5, name: "Finalizing", progress: 100 },
];

export default function GenerationProgress({ jobId, onComplete }: GenerationProgressProps) {
  const [hasCompleted, setHasCompleted] = useState(false);

  const { data: job, isLoading } = useQuery<GenerationJob>({
    queryKey: ["/api/jobs", jobId],
    refetchInterval: hasCompleted ? false : 2000,
    enabled: !!jobId,
  });

  const { data: generatedImage } = useQuery<GeneratedImage>({
    queryKey: ["/api/images", job?.resultImageId],
    enabled: !!job?.resultImageId && job?.status === "completed",
  });

  useEffect(() => {
    if (job?.status === "completed" && generatedImage && !hasCompleted) {
      setHasCompleted(true);
      // Delay callback to show completion animation
      setTimeout(() => {
        onComplete(generatedImage);
      }, 2000);
    }
  }, [job, generatedImage, hasCompleted, onComplete]);

  if (isLoading || !job) {
    return (
      <Card className="bg-cyber-card cyber-glass border-cyber-border w-full max-w-2xl neon-glow-yellow">
        <CardContent className="p-8 smoke-bg">
          <div className="text-center">
            <div className="w-16 h-16 border-4 gradient-cyber border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <h3 className="text-lg font-bold font-mono neon-text-yellow mb-2 animate-neon-rainbow-glow">PREPARING GENERATION</h3>
            <p className="text-muted-foreground font-mono">SETTING UP YOUR AI IMAGE GENERATION...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const currentStep = GENERATION_STEPS.find(
    step => job.progress >= step.progress - 10 && job.progress < step.progress + 10
  ) || GENERATION_STEPS[0];

  const isCompleted = job.status === "completed";
  const isFailed = job.status === "failed";

  return (
    <div className="w-full max-w-2xl space-y-6">
      {/* Main Progress Card */}
      <Card className="bg-dark-surface border-dark-border">
        <CardContent className="p-8">
          <div className="text-center mb-6">
            <div className="relative inline-block mb-4">
              {isCompleted ? (
                <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center animate-pulse">
                  <CheckCircle className="w-8 h-8 text-green-400" />
                </div>
              ) : isFailed ? (
                <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center">
                  <X className="w-8 h-8 text-red-400" />
                </div>
              ) : (
                <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin">
                  <div className="w-full h-full bg-gradient-to-r from-primary to-secondary rounded-full opacity-20"></div>
                </div>
              )}
            </div>

            <h3 className="text-xl font-semibold text-white mb-2">
              {isCompleted ? "Generation Complete!" : isFailed ? "Generation Failed" : "Generating Your Image"}
            </h3>

            <div className="flex items-center justify-center space-x-2 mb-4">
              <Badge variant="outline" className="border-primary text-primary">
                <Zap className="w-3 h-3 mr-1" />
                {job.model}
              </Badge>
              <Badge variant="outline" className="border-accent text-accent">
                <Sparkles className="w-3 h-3 mr-1" />
                {job.style}
              </Badge>
            </div>

            {!isFailed && (
              <div className="mb-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-400">Progress</span>
                  <span className="text-sm text-gray-400">{job.progress}%</span>
                </div>
                <Progress 
                  value={job.progress} 
                  className="h-2 bg-dark-card"
                />
              </div>
            )}

            {job.estimatedTime && !isCompleted && !isFailed && (
              <div className="flex items-center justify-center text-sm text-gray-400">
                <Clock className="w-4 h-4 mr-1" />
                Estimated time: {Math.max(1, Math.ceil((job.estimatedTime * (100 - job.progress)) / 100))}s remaining
              </div>
            )}

            {isFailed && job.errorMessage && (
              <p className="text-red-400 text-sm mt-2">{job.errorMessage}</p>
            )}
          </div>

          {/* Generation Steps */}
          {!isFailed && (
            <div className="space-y-3">
              {GENERATION_STEPS.map((step, index) => {
                const isActive = currentStep.id === step.id;
                const isComplete = job.progress >= step.progress;

                return (
                  <div
                    key={step.id}
                    className={cn(
                      "flex items-center space-x-3 p-3 rounded-lg transition-all",
                      isActive && "bg-primary/10 border border-primary/20",
                      isComplete && !isActive && "opacity-60"
                    )}
                  >
                    <div className={cn(
                      "w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold transition-colors",
                      isComplete 
                        ? "bg-green-500 text-white" 
                        : isActive 
                          ? "bg-primary text-white animate-pulse" 
                          : "bg-dark-card text-gray-400 border border-dark-border"
                    )}>
                      {isComplete ? "✓" : step.id}
                    </div>
                    <span className={cn(
                      "font-medium transition-colors",
                      isActive ? "text-white" : "text-gray-400"
                    )}>
                      {step.name}
                    </span>
                    {isActive && !isComplete && (
                      <div className="flex space-x-1">
                        <div className="w-1 h-1 bg-primary rounded-full animate-bounce"></div>
                        <div className="w-1 h-1 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0.1s" }}></div>
                        <div className="w-1 h-1 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Generation Details */}
      <Card className="bg-dark-surface border-dark-border">
        <CardContent className="p-6">
          <h4 className="font-semibold text-white mb-4">Generation Details</h4>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-400">Prompt:</span>
              <span className="text-white text-right max-w-xs truncate">{job.prompt}</span>
            </div>
            {job.negativePrompt && (
              <div className="flex justify-between">
                <span className="text-gray-400">Negative Prompt:</span>
                <span className="text-white text-right max-w-xs truncate">{job.negativePrompt}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-gray-400">Aspect Ratio:</span>
              <span className="text-white">{job.aspectRatio}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Steps:</span>
              <span className="text-white">{job.steps}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">CFG Scale:</span>
              <span className="text-white">{job.cfgScale}</span>
            </div>
            {job.seed && (
              <div className="flex justify-between">
                <span className="text-gray-400">Seed:</span>
                <span className="text-white font-mono">{job.seed}</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Preview Card (when completed) */}
      {isCompleted && generatedImage && (
        <Card className="bg-dark-surface border-dark-border animate-in fade-in duration-1000">
          <CardContent className="p-6">
            <div className="text-center">
              <img
                src={generatedImage.imageUrl}
                alt={generatedImage.prompt}
                className="w-full max-w-md mx-auto rounded-lg shadow-lg mb-4"
                onError={(e) => {
                  e.currentTarget.src = "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?w=400";
                }}
              />
              <div className="flex items-center justify-center space-x-4 text-sm text-gray-400">
                <span>{generatedImage.width} x {generatedImage.height}</span>
                <span>•</span>
                <span>{generatedImage.generationTime}s</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Action Buttons */}
      {(isCompleted || isFailed) && (
        <div className="flex justify-center">
          <Button
            variant="outline"
            onClick={() => window.location.reload()}
            className="border-dark-border"
          >
            {isFailed ? "Try Again" : "Generate Another"}
          </Button>
        </div>
      )}
    </div>
  );
}
