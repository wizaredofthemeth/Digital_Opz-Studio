import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Wand2, Palette, Image, Layers, Sparkles, Zap, Settings, Code, 
  Paintbrush, Cpu, Eye, Download, Upload, Save, Play, Pause, 
  RotateCcw, RotateCw, Crop, Scissors, Copy, Move, Grid, 
  Filter, Contrast, Sun, Sliders, Blend,
  Type, Frame, Sticker, Shapes
} from "lucide-react";

interface AdvancedToolsProps {
  onApplyEffect: (effect: any) => void;
}

export default function AdvancedTools({ onApplyEffect }: AdvancedToolsProps) {
  const [activeTab, setActiveTab] = useState("perchance");
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  // Perchance.com style tools
  const perchanceTools = [
    { name: "TEXT", icon: Type, category: "content" },
    { name: "CHAR", icon: Sticker, category: "content" },
    { name: "POSE", icon: Move, category: "content" },
    { name: "EXPR", icon: Eye, category: "content" },
    { name: "STYLE", icon: Paintbrush, category: "style" },
    { name: "LIGHT", icon: Sun, category: "style" },
    { name: "COLOR", icon: Palette, category: "style" },
    { name: "MOOD", icon: Sparkles, category: "style" },
    { name: "SCENE", icon: Grid, category: "environment" },
    { name: "BG", icon: Image, category: "environment" },
    { name: "FRAME", icon: Frame, category: "environment" },
    { name: "COMP", icon: Layers, category: "environment" }
  ];

  // Advanced image editing tools
  const editingTools = [
    { name: "CROP", icon: Crop, action: "crop" },
    { name: "RESIZE", icon: Move, action: "resize" },
    { name: "ROTATE", icon: RotateCw, action: "rotate" },
    { name: "FLIP", icon: RotateCcw, action: "flip" },
    { name: "FILTER", icon: Filter, action: "filter" },
    { name: "BLEND", icon: Blend, action: "blend" },
    { name: "MASK", icon: Scissors, action: "mask" },
    { name: "LAYER", icon: Layers, action: "layer" }
  ];

  // AI enhancement tools
  const aiTools = [
    { name: "UPSCALE", icon: Zap, action: "upscale" },
    { name: "ENHANCE", icon: Sparkles, action: "enhance" },
    { name: "DENOISE", icon: Settings, action: "denoise" },
    { name: "RESTORE", icon: Wand2, action: "restore" },
    { name: "COLORIZE", icon: Palette, action: "colorize" },
    { name: "ANIMATE", icon: Play, action: "animate" },
    { name: "MORPH", icon: Cpu, action: "morph" },
    { name: "STYLE", icon: Paintbrush, action: "transfer" }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50">
      {/* Main Tools Panel */}
      <Card className="bg-cyber-surface cyber-glass border-cyber-border border-t-2 rounded-none shadow-2xl">
        <CardContent className="p-4">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-cyber-card mb-4">
              <TabsTrigger value="perchance" className="font-mono text-xs data-[state=active]:neon-text-cyan data-[state=active]:neon-glow-cyan">
                PERCHANCE
              </TabsTrigger>
              <TabsTrigger value="edit" className="font-mono text-xs data-[state=active]:neon-text-pink data-[state=active]:neon-glow-pink">
                EDIT
              </TabsTrigger>
              <TabsTrigger value="ai" className="font-mono text-xs data-[state=active]:neon-text-yellow data-[state=active]:neon-glow-yellow">
                AI TOOLS
              </TabsTrigger>
              <TabsTrigger value="export" className="font-mono text-xs data-[state=active]:neon-text-green data-[state=active]:neon-glow-green">
                EXPORT
              </TabsTrigger>
            </TabsList>

            {/* Perchance.com Style Tools */}
            <TabsContent value="perchance">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-mono neon-text-cyan">PERCHANCE ADVANCED CONTROLS</h3>
                  <Badge variant="outline" className="neon-glow-cyan font-mono text-xs">
                    UNLIMITED
                  </Badge>
                </div>
                
                <div className="grid grid-cols-6 gap-2">
                  {perchanceTools.map((tool) => (
                    <Button
                      key={tool.name}
                      variant="outline"
                      size="sm"
                      className="flex flex-col items-center p-2 h-auto cyber-glass border-cyber-border hover:neon-glow-cyan transition-all duration-300"
                      onClick={() => onApplyEffect({ type: 'perchance', tool: tool.name.toLowerCase() })}
                    >
                      <tool.icon className="w-4 h-4 mb-1 text-cyber-neon-cyan" />
                      <span className="text-xs font-mono">{tool.name}</span>
                    </Button>
                  ))}
                </div>

                {/* Quick Prompts */}
                <div className="grid grid-cols-3 gap-2">
                  <Input 
                    placeholder="Character..." 
                    className="font-mono text-xs bg-cyber-card border-cyber-border"
                  />
                  <Input 
                    placeholder="Style..." 
                    className="font-mono text-xs bg-cyber-card border-cyber-border"
                  />
                  <Input 
                    placeholder="Environment..." 
                    className="font-mono text-xs bg-cyber-card border-cyber-border"
                  />
                </div>
              </div>
            </TabsContent>

            {/* Image Editing Tools */}
            <TabsContent value="edit">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-mono neon-text-pink">PROFESSIONAL EDITING SUITE</h3>
                  <Badge variant="outline" className="neon-glow-pink font-mono text-xs">
                    PRO LEVEL
                  </Badge>
                </div>
                
                <div className="grid grid-cols-8 gap-2">
                  {editingTools.map((tool) => (
                    <Button
                      key={tool.name}
                      variant="outline"
                      size="sm"
                      className="flex flex-col items-center p-2 h-auto cyber-glass border-cyber-border hover:neon-glow-pink transition-all duration-300"
                      onClick={() => onApplyEffect({ type: 'edit', action: tool.action })}
                    >
                      <tool.icon className="w-4 h-4 mb-1 text-cyber-neon-pink" />
                      <span className="text-xs font-mono">{tool.name}</span>
                    </Button>
                  ))}
                </div>

                {/* Quick Adjustments */}
                <div className="grid grid-cols-4 gap-4">
                  <div className="space-y-2">
                    <Label className="text-xs font-mono text-cyber-neon-pink">BRIGHTNESS</Label>
                    <Slider defaultValue={[50]} max={100} step={1} className="w-full" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs font-mono text-cyber-neon-pink">CONTRAST</Label>
                    <Slider defaultValue={[50]} max={100} step={1} className="w-full" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs font-mono text-cyber-neon-pink">SATURATION</Label>
                    <Slider defaultValue={[50]} max={100} step={1} className="w-full" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs font-mono text-cyber-neon-pink">BLUR</Label>
                    <Slider defaultValue={[0]} max={20} step={1} className="w-full" />
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* AI Enhancement Tools */}
            <TabsContent value="ai">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-mono neon-text-yellow">AI ENHANCEMENT SUITE</h3>
                  <Badge variant="outline" className="neon-glow-yellow font-mono text-xs">
                    AI POWERED
                  </Badge>
                </div>
                
                <div className="grid grid-cols-8 gap-2">
                  {aiTools.map((tool) => (
                    <Button
                      key={tool.name}
                      variant="outline"
                      size="sm"
                      className="flex flex-col items-center p-2 h-auto cyber-glass border-cyber-border hover:neon-glow-yellow transition-all duration-300"
                      onClick={() => onApplyEffect({ type: 'ai', action: tool.action })}
                    >
                      <tool.icon className="w-4 h-4 mb-1 text-cyber-neon-yellow" />
                      <span className="text-xs font-mono">{tool.name}</span>
                    </Button>
                  ))}
                </div>

                {/* AI Settings */}
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label className="text-xs font-mono text-cyber-neon-yellow">AI STRENGTH</Label>
                    <Slider defaultValue={[75]} max={100} step={5} className="w-full" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs font-mono text-cyber-neon-yellow">DETAIL LEVEL</Label>
                    <Select>
                      <SelectTrigger className="bg-cyber-card border-cyber-border font-mono text-xs">
                        <SelectValue placeholder="Select..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">LOW</SelectItem>
                        <SelectItem value="medium">MEDIUM</SelectItem>
                        <SelectItem value="high">HIGH</SelectItem>
                        <SelectItem value="ultra">ULTRA</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs font-mono text-cyber-neon-yellow">PROCESSING</Label>
                    <div className="flex items-center space-x-2">
                      <Switch />
                      <span className="text-xs font-mono">REAL-TIME</span>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Export Tools */}
            <TabsContent value="export">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-mono neon-text-green">EXPORT & SHARING</h3>
                  <Badge variant="outline" className="neon-glow-green font-mono text-xs">
                    UNLIMITED
                  </Badge>
                </div>
                
                <div className="grid grid-cols-6 gap-2">
                  {[
                    { name: "PNG", icon: Download },
                    { name: "JPG", icon: Download },
                    { name: "WEBP", icon: Download },
                    { name: "SVG", icon: Download },
                    { name: "PDF", icon: Download },
                    { name: "GIF", icon: Download },
                    { name: "MP4", icon: Play },
                    { name: "SHARE", icon: Upload },
                    { name: "PRINT", icon: Copy },
                    { name: "SAVE", icon: Save },
                    { name: "BATCH", icon: Layers },
                    { name: "CLOUD", icon: Upload }
                  ].map((format) => (
                    <Button
                      key={format.name}
                      variant="outline"
                      size="sm"
                      className="flex flex-col items-center p-2 h-auto cyber-glass border-cyber-border hover:neon-glow-green transition-all duration-300"
                      onClick={() => onApplyEffect({ type: 'export', format: format.name.toLowerCase() })}
                    >
                      <format.icon className="w-4 h-4 mb-1 text-cyber-neon-green" />
                      <span className="text-xs font-mono">{format.name}</span>
                    </Button>
                  ))}
                </div>

                {/* Export Settings */}
                <div className="grid grid-cols-4 gap-4">
                  <div className="space-y-2">
                    <Label className="text-xs font-mono text-cyber-neon-green">QUALITY</Label>
                    <Slider defaultValue={[95]} max={100} step={5} className="w-full" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs font-mono text-cyber-neon-green">SIZE</Label>
                    <Select>
                      <SelectTrigger className="bg-cyber-card border-cyber-border font-mono text-xs">
                        <SelectValue placeholder="Original" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="original">ORIGINAL</SelectItem>
                        <SelectItem value="large">LARGE</SelectItem>
                        <SelectItem value="medium">MEDIUM</SelectItem>
                        <SelectItem value="small">SMALL</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs font-mono text-cyber-neon-green">WATERMARK</Label>
                    <div className="flex items-center space-x-2">
                      <Switch />
                      <span className="text-xs font-mono">NONE</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs font-mono text-cyber-neon-green">BATCH</Label>
                    <div className="flex items-center space-x-2">
                      <Switch />
                      <span className="text-xs font-mono">ENABLED</span>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}