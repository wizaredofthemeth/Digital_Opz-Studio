import { useState } from "react";
import { type GeneratedImage } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Download, 
  Share2, 
  Heart, 
  Eye, 
  Clock, 
  Zap, 
  Sparkles, 
  Copy,
  ExternalLink 
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ImageCardProps {
  image: GeneratedImage;
  compact?: boolean;
}

export default function ImageCard({ image, compact = false }: ImageCardProps) {
  const { toast } = useToast();
  const [showDetails, setShowDetails] = useState(false);
  const [isLiked, setIsLiked] = useState(false);

  const handleCopyPrompt = () => {
    navigator.clipboard.writeText(image.prompt);
    toast({
      title: "Copied to clipboard",
      description: "The prompt has been copied to your clipboard.",
    });
  };

  const handleDownload = () => {
    const link = document.createElement("a");
    link.href = image.imageUrl;
    link.download = `ai-generated-${image.id}.jpg`;
    link.click();
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `AI Generated Image - ${image.prompt.slice(0, 50)}...`,
          text: image.prompt,
          url: image.imageUrl,
        });
      } catch (error) {
        // Fallback to clipboard
        navigator.clipboard.writeText(image.imageUrl);
        toast({
          title: "Link copied",
          description: "Image URL has been copied to your clipboard.",
        });
      }
    } else {
      navigator.clipboard.writeText(image.imageUrl);
      toast({
        title: "Link copied",
        description: "Image URL has been copied to your clipboard.",
      });
    }
  };

  const handleLike = () => {
    setIsLiked(!isLiked);
    toast({
      title: isLiked ? "Removed from favorites" : "Added to favorites",
      description: isLiked ? "Image removed from your favorites." : "Image added to your favorites.",
    });
  };

  return (
    <>
      <Card className="bg-cyber-card cyber-glass border-cyber-border group hover:neon-glow-cyan transition-all duration-300 overflow-hidden">
        <CardContent className="p-0">
          <div className="relative">
            <img
              src={image.thumbnailUrl || image.imageUrl}
              alt={image.prompt}
              className="w-full aspect-square object-cover cursor-pointer transition-transform duration-300 group-hover:scale-105 group-hover:animate-cyber-pulse"
              onClick={() => setShowDetails(true)}
              onError={(e) => {
                e.currentTarget.src = "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?w=400";
              }}
            />
            
            {/* Overlay on hover */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-end justify-between p-4">
              <div className="flex space-x-2">
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowDetails(true);
                  }}
                  className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
                >
                  <Eye className="w-4 h-4" />
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDownload();
                  }}
                  className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
                >
                  <Download className="w-4 h-4" />
                </Button>
              </div>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  handleLike();
                }}
                className={`p-2 ${isLiked ? 'text-red-400' : 'text-white'} hover:text-red-400`}
              >
                <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
              </Button>
            </div>

            {/* Top badges */}
            <div className="absolute top-3 right-3 flex space-x-1">
              <Badge className="bg-black/70 text-white text-xs backdrop-blur-sm">
                {image.aspectRatio}
              </Badge>
            </div>

            {/* Generation time badge */}
            {image.generationTime && (
              <div className="absolute top-3 left-3">
                <Badge className="bg-black/70 text-white text-xs backdrop-blur-sm flex items-center">
                  <Clock className="w-3 h-3 mr-1" />
                  {image.generationTime}s
                </Badge>
              </div>
            )}
          </div>

          {!compact && (
            <div className="p-4">
              <p className="text-white font-medium text-sm line-clamp-2 mb-3 leading-relaxed">
                {image.prompt}
              </p>
              
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <Badge variant="outline" className="text-xs border-primary/30 text-primary bg-primary/5">
                    <Zap className="w-3 h-3 mr-1" />
                    {image.model.replace("-", " ").toUpperCase()}
                  </Badge>
                  <Badge variant="outline" className="text-xs border-secondary/30 text-secondary bg-secondary/5">
                    <Sparkles className="w-3 h-3 mr-1" />
                    {image.style}
                  </Badge>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-500">
                  {new Date(image.createdAt!).toLocaleDateString('en-US', { 
                    month: 'short', 
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </span>
                
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleCopyPrompt}
                    className="text-gray-400 hover:text-white p-1 h-auto"
                  >
                    <Copy className="w-3 h-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleShare}
                    className="text-gray-400 hover:text-white p-1 h-auto"
                  >
                    <Share2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Image Details Modal */}
      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent className="max-w-5xl bg-dark-surface border-dark-border max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center">
              <Sparkles className="w-5 h-5 mr-2 text-primary" />
              AI Generated Image
            </DialogTitle>
          </DialogHeader>
          
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            {/* Image Display */}
            <div className="lg:col-span-3">
              <div className="relative group">
                <img
                  src={image.imageUrl}
                  alt={image.prompt}
                  className="w-full rounded-lg shadow-lg"
                  onError={(e) => {
                    e.currentTarget.src = "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?w=800";
                  }}
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors rounded-lg"></div>
              </div>
              
              {/* Action Buttons */}
              <div className="flex space-x-2 mt-4">
                <Button onClick={handleDownload} className="flex-1 bg-primary hover:bg-primary/90">
                  <Download className="w-4 h-4 mr-2" />
                  Download Full Resolution
                </Button>
                <Button variant="outline" onClick={handleShare} className="border-dark-border">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share
                </Button>
                <Button 
                  variant="outline" 
                  onClick={handleLike}
                  className={`border-dark-border ${isLiked ? 'text-red-400 border-red-400' : ''}`}
                >
                  <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
                </Button>
              </div>
            </div>

            {/* Image Details */}
            <div className="lg:col-span-2 space-y-6">
              {/* Prompt Section */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold text-white">Prompt</h3>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleCopyPrompt}
                    className="text-gray-400 hover:text-white"
                  >
                    <Copy className="w-4 h-4 mr-1" />
                    Copy
                  </Button>
                </div>
                <div className="bg-dark-card p-4 rounded-lg border border-dark-border">
                  <p className="text-gray-300 text-sm leading-relaxed">{image.prompt}</p>
                </div>
              </div>
              
              {image.negativePrompt && (
                <div>
                  <h3 className="font-semibold text-white mb-2">Negative Prompt</h3>
                  <div className="bg-dark-card p-4 rounded-lg border border-dark-border">
                    <p className="text-gray-300 text-sm leading-relaxed">{image.negativePrompt}</p>
                  </div>
                </div>
              )}

              {/* Technical Details */}
              <div>
                <h3 className="font-semibold text-white mb-3">Generation Details</h3>
                <div className="bg-dark-card p-4 rounded-lg border border-dark-border space-y-3">
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <span className="text-gray-400 block mb-1">Model</span>
                      <Badge variant="outline" className="text-xs border-primary/30 text-primary">
                        <Zap className="w-3 h-3 mr-1" />
                        {image.model.replace("-", " ").toUpperCase()}
                      </Badge>
                    </div>
                    <div>
                      <span className="text-gray-400 block mb-1">Style</span>
                      <Badge variant="outline" className="text-xs border-secondary/30 text-secondary">
                        <Sparkles className="w-3 h-3 mr-1" />
                        {image.style.charAt(0).toUpperCase() + image.style.slice(1)}
                      </Badge>
                    </div>
                    <div>
                      <span className="text-gray-400 block mb-1">Dimensions</span>
                      <p className="text-white font-mono text-sm">{image.width} × {image.height}</p>
                    </div>
                    <div>
                      <span className="text-gray-400 block mb-1">Aspect Ratio</span>
                      <p className="text-white font-medium text-sm">{image.aspectRatio}</p>
                    </div>
                    <div>
                      <span className="text-gray-400 block mb-1">Steps</span>
                      <p className="text-white font-medium text-sm">{image.steps}</p>
                    </div>
                    <div>
                      <span className="text-gray-400 block mb-1">CFG Scale</span>
                      <p className="text-white font-medium text-sm">{image.cfgScale}</p>
                    </div>
                    {image.seed && (
                      <>
                        <div className="col-span-2">
                          <span className="text-gray-400 block mb-1">Seed</span>
                          <p className="text-white font-mono text-sm break-all">{image.seed}</p>
                        </div>
                      </>
                    )}
                    <div>
                      <span className="text-gray-400 block mb-1">Generation Time</span>
                      <p className="text-white font-medium text-sm flex items-center">
                        <Clock className="w-3 h-3 mr-1" />
                        {image.generationTime}s
                      </p>
                    </div>
                    <div>
                      <span className="text-gray-400 block mb-1">Created</span>
                      <p className="text-white font-medium text-sm">
                        {new Date(image.createdAt!).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Color Palette */}
              {image.colorPalette && Array.isArray(image.colorPalette) && image.colorPalette.length > 0 && (
                <div>
                  <h3 className="font-semibold text-white mb-2">Color Palette</h3>
                  <div className="bg-dark-card p-4 rounded-lg border border-dark-border">
                    <div className="flex space-x-2">
                      {image.colorPalette.map((color, index) => (
                        <div
                          key={index}
                          className="w-8 h-8 rounded-full border-2 border-gray-600 cursor-pointer hover:scale-110 transition-transform"
                          style={{ backgroundColor: color }}
                          title={color}
                          onClick={() => {
                            navigator.clipboard.writeText(color);
                            toast({
                              title: "Color copied",
                              description: `${color} has been copied to your clipboard.`,
                            });
                          }}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
