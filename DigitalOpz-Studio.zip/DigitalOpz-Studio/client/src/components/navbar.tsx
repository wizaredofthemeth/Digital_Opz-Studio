import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { type User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Sparkles, 
  Crown, 
  User as UserIcon, 
  Settings, 
  LogOut, 
  Menu, 
  X,
  Home,
  Image,
  Palette,
  Zap,
  Gift
} from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

export default function Navbar() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Get current user
  const { data: user } = useQuery<User>({
    queryKey: ["/api/user/current"],
  });

  const navigation = [
    { name: "Generate", href: "/", icon: Home, current: location === "/" },
    { name: "Gallery", href: "/gallery", icon: Image, current: location === "/gallery" },
    { name: "Models", href: "/models", icon: Zap, current: location === "/models" },
    { name: "Templates", href: "/templates", icon: Palette, current: location === "/templates" },
  ];

  return (
    <nav className="bg-cyber-surface cyber-glass border-b border-cyber-border px-6 py-4 sticky top-0 z-50 backdrop-blur-sm">
      <div className="flex items-center justify-between">
        {/* Logo and Brand */}
        <div className="flex items-center space-x-8">
          <Link href="/" className="flex items-center space-x-3 group">
            <div className="w-10 h-10 neon-glow-cyan rounded flex items-center justify-center transition-all duration-300 group-hover:animate-cyber-pulse">
              <Sparkles className="text-cyber-neon-cyan text-lg animate-neon-flicker" />
            </div>
            <h1 className="text-2xl font-bold font-mono tracking-wider group-hover:animate-glitch transition-all animate-neon-rainbow-glow" style={{
              background: 'linear-gradient(90deg, var(--cyber-neon-red), var(--cyber-neon-orange), var(--cyber-neon-yellow), var(--cyber-neon-green), var(--cyber-neon-cyan), var(--cyber-neon-blue), var(--cyber-neon-purple), var(--cyber-neon-pink))',
              backgroundSize: '200% 100%',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              animation: 'rainbow-flow 3s linear infinite'
            }}>
              DIGITAL-OPZ EDITOR
            </h1>
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            {navigation.map((item) => (
              <Link key={item.name} href={item.href}>
                <Button
                  variant="ghost"
                  className={cn(
                    "text-muted-foreground hover:neon-text-pink hover:neon-glow-pink transition-all duration-300 font-mono tracking-wide border-0 rounded",
                    item.current && "neon-text-cyan neon-glow-cyan animate-cyber-pulse"
                  )}
                >
                  <item.icon className="w-4 h-4 mr-2" />
                  {item.name.toUpperCase()}
                </Button>
              </Link>
            ))}
          </div>
        </div>
        
        {/* Right Side Actions */}
        <div className="flex items-center space-x-4">
          {/* User Credits/Status */}
          {user && (
            <div className="hidden sm:flex items-center space-x-3">
              <div className="cyber-glass rounded px-4 py-2 flex items-center space-x-2 terminal-border">
                <Sparkles className="w-4 h-4 text-cyber-neon-cyan animate-neon-flicker" />
                <span className="text-sm font-mono neon-text-cyan">
                  UNLIMITED ACCESS
                </span>
              </div>
            </div>
          )}

          {/* User Menu */}
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative p-2 hover:neon-glow-cyan transition-all duration-300">
                  <div className="w-8 h-8 gradient-cyber rounded-full flex items-center justify-center animate-cyber-pulse">
                    <UserIcon className="w-4 h-4 text-black" />
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-cyber-card cyber-glass border-cyber-border w-56">
                <div className="px-3 py-2 border-b border-cyber-border">
                  <p className="text-sm font-mono neon-text-cyan tracking-wide">{user.username}</p>
                  <p className="text-xs text-muted-foreground font-mono">{user.email}</p>
                  <div className="flex items-center space-x-2 mt-2">
                    <div className="neon-glow-yellow rounded px-2 py-1">
                      <span className="text-xs neon-text-yellow font-mono">UNLIMITED</span>
                    </div>
                    <span className="text-xs neon-text-green font-mono animate-neon-flicker">
                      ∞ CREDITS
                    </span>
                  </div>
                </div>
                
                <DropdownMenuItem className="cursor-pointer text-muted-foreground hover:neon-text-cyan font-mono">
                  <Settings className="w-4 h-4 mr-2" />
                  SETTINGS
                </DropdownMenuItem>
                
                <DropdownMenuItem className="cursor-pointer text-muted-foreground hover:neon-text-cyan font-mono">
                  <Image className="w-4 h-4 mr-2" />
                  MY GENERATIONS
                </DropdownMenuItem>
                
                <DropdownMenuSeparator className="border-cyber-border" />
                
                <DropdownMenuItem className="cursor-pointer text-muted-foreground hover:neon-text-pink font-mono">
                  <LogOut className="w-4 h-4 mr-2" />
                  SIGN OUT
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <div className="flex items-center space-x-2">
              <Button variant="ghost" className="text-gray-400 hover:text-white">
                Sign In
              </Button>
              <Button className="bg-primary hover:bg-primary/90">
                Get Started
              </Button>
            </div>
          )}

          {/* Mobile Menu Button */}
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="sm" className="md:hidden text-gray-400">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="bg-dark-surface border-dark-border w-80">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
                    <Sparkles className="text-white text-xs" />
                  </div>
                  <h2 className="font-semibold text-white">AI Image Studio</h2>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-gray-400"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>

              {/* Mobile Navigation */}
              <div className="space-y-2 mb-6">
                {navigation.map((item) => (
                  <Link key={item.name} href={item.href}>
                    <Button
                      variant="ghost"
                      className={cn(
                        "w-full justify-start text-gray-400 hover:text-white hover:bg-dark-card transition-colors",
                        item.current && "text-white bg-dark-card"
                      )}
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      <item.icon className="w-4 h-4 mr-3" />
                      {item.name}
                    </Button>
                  </Link>
                ))}
              </div>

              {/* Mobile User Info */}
              {user && (
                <div className="border-t border-dark-border pt-6 space-y-4">
                  <div className="bg-dark-card rounded-lg p-4">
                    <div className="flex items-center space-x-3 mb-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center relative">
                        <UserIcon className="w-5 h-5 text-white" />
                        {user.isPro && (
                          <Crown className="w-3 h-3 text-accent absolute -top-1 -right-1" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium text-white">{user.username}</p>
                        <p className="text-xs text-gray-400">{user.email}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Badge variant={user.isPro ? "default" : "outline"}>
                        {user.isPro ? "Pro Plan" : "Free Plan"}
                      </Badge>
                      <span className="text-sm text-gray-400">
                        {user.credits === 0 ? "Unlimited" : `${user.credits} credits`}
                      </span>
                    </div>
                  </div>

                  {!user.isPro && (
                    <Button className="w-full bg-gradient-to-r from-accent to-orange-500 hover:from-accent/90 hover:to-orange-500/90">
                      <Crown className="w-4 h-4 mr-2" />
                      Upgrade to Pro
                    </Button>
                  )}
                </div>
              )}
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
