import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  Code, 
  Eye, 
  Download, 
  Copy, 
  Play, 
  Settings,
  Palette,
  Type,
  Image,
  Layers,
  Zap,
  Sparkles,
  FileCode,
  Monitor
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface HtmlEditorProps {
  onExport?: (html: string, css: string, js: string) => void;
}

const HTML_TEMPLATES = [
  {
    name: "BASIC PAGE",
    html: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Page</title>
</head>
<body>
    <h1>Hello World!</h1>
    <p>This is a basic HTML page.</p>
</body>
</html>`,
    css: `body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 20px;
    background: #f0f0f0;
}

h1 {
    color: #333;
    text-align: center;
}`,
    js: `console.log('Page loaded!');`
  },
  {
    name: "CYBERPUNK THEME",
    html: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cyberpunk Page</title>
</head>
<body>
    <div class="cyber-container">
        <h1 class="neon-title">DIGITAL-OPZ</h1>
        <div class="content">
            <p class="cyber-text">Welcome to the future.</p>
            <button class="cyber-btn" onclick="activate()">ACTIVATE</button>
        </div>
    </div>
</body>
</html>`,
    css: `body {
    margin: 0;
    padding: 0;
    background: linear-gradient(45deg, #0a0a0a, #1a1a2e, #16213e);
    color: #00ffff;
    font-family: 'Courier New', monospace;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
}

.cyber-container {
    text-align: center;
    padding: 2rem;
    border: 2px solid #00ffff;
    border-radius: 10px;
    background: rgba(0, 255, 255, 0.1);
    box-shadow: 0 0 30px #00ffff;
}

.neon-title {
    font-size: 3rem;
    text-shadow: 0 0 10px #00ffff, 0 0 20px #00ffff, 0 0 30px #00ffff;
    animation: flicker 2s infinite alternate;
}

.cyber-btn {
    background: transparent;
    border: 2px solid #ff0080;
    color: #ff0080;
    padding: 1rem 2rem;
    font-family: inherit;
    font-size: 1.2rem;
    cursor: pointer;
    transition: all 0.3s;
}

.cyber-btn:hover {
    background: #ff0080;
    color: black;
    box-shadow: 0 0 20px #ff0080;
}

@keyframes flicker {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.8; }
}`,
    js: `function activate() {
    alert('SYSTEM ACTIVATED!');
    document.body.style.animation = 'rainbow 2s infinite';
}

document.addEventListener('DOMContentLoaded', function() {
    console.log('Cyberpunk interface loaded!');
});`
  },
  {
    name: "INTERACTIVE GALLERY",
    html: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interactive Gallery</title>
</head>
<body>
    <div class="gallery-container">
        <h1>AI GENERATED GALLERY</h1>
        <div class="gallery-grid" id="gallery">
            <!-- Images will be added dynamically -->
        </div>
        <button onclick="addImage()">ADD IMAGE</button>
    </div>
</body>
</html>`,
    css: `.gallery-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 2rem;
    background: #1a1a1a;
    color: white;
    min-height: 100vh;
}

.gallery-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1rem;
    margin: 2rem 0;
}

.gallery-item {
    position: relative;
    overflow: hidden;
    border-radius: 8px;
    transition: transform 0.3s;
}

.gallery-item:hover {
    transform: scale(1.05);
}

.gallery-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
}

button {
    background: linear-gradient(45deg, #ff6b6b, #4ecdc4);
    border: none;
    color: white;
    padding: 1rem 2rem;
    border-radius: 25px;
    cursor: pointer;
    font-weight: bold;
}`,
    js: `const images = [
    'https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?w=400',
    'https://images.unsplash.com/photo-1614728264156-0def8efe0522?w=400',
    'https://images.unsplash.com/photo-1600298881974-6be191ceeda1?w=400'
];

function addImage() {
    const gallery = document.getElementById('gallery');
    const randomImage = images[Math.floor(Math.random() * images.length)];
    
    const item = document.createElement('div');
    item.className = 'gallery-item';
    item.innerHTML = \`<img src="\${randomImage}" alt="AI Generated">\`;
    
    gallery.appendChild(item);
}

// Initialize with some images
document.addEventListener('DOMContentLoaded', function() {
    for(let i = 0; i < 6; i++) {
        addImage();
    }
});`
  }
];

export default function HtmlEditor({ onExport }: HtmlEditorProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("html");
  const [htmlCode, setHtmlCode] = useState(HTML_TEMPLATES[0].html);
  const [cssCode, setCssCode] = useState(HTML_TEMPLATES[0].css);
  const [jsCode, setJsCode] = useState(HTML_TEMPLATES[0].js);
  const [previewMode, setPreviewMode] = useState<"desktop" | "mobile">("desktop");
  const [isPreviewVisible, setIsPreviewVisible] = useState(true);

  const generatePreview = () => {
    const fullHtml = `
      ${htmlCode}
      <style>${cssCode}</style>
      <script>${jsCode}</script>
    `;
    return fullHtml;
  };

  const handleCopyCode = () => {
    const fullCode = generatePreview();
    navigator.clipboard.writeText(fullCode);
    toast({
      title: "CODE COPIED",
      description: "Full HTML code copied to clipboard",
    });
  };

  const handleDownload = () => {
    const fullCode = generatePreview();
    const blob = new Blob([fullCode], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'generated-page.html';
    a.click();
    URL.revokeObjectURL(url);
    
    toast({
      title: "FILE DOWNLOADED",
      description: "HTML file saved successfully",
    });
  };

  const loadTemplate = (template: typeof HTML_TEMPLATES[0]) => {
    setHtmlCode(template.html);
    setCssCode(template.css);
    setJsCode(template.js);
    toast({
      title: "TEMPLATE LOADED",
      description: `${template.name} template applied`,
    });
  };

  return (
    <div className="h-full flex flex-col bg-cyber-surface">
      {/* Header */}
      <div className="p-4 border-b border-cyber-border smoke-bg">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold font-mono tracking-wider animate-neon-rainbow-glow">
            HTML EDITOR
          </h2>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPreviewMode(previewMode === "desktop" ? "mobile" : "desktop")}
              className="font-mono"
            >
              <Monitor className="w-4 h-4 mr-2" />
              {previewMode.toUpperCase()}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsPreviewVisible(!isPreviewVisible)}
              className="font-mono"
            >
              <Eye className="w-4 h-4 mr-2" />
              {isPreviewVisible ? "HIDE" : "SHOW"}
            </Button>
          </div>
        </div>

        {/* Templates */}
        <div className="flex flex-wrap gap-2 mb-4">
          {HTML_TEMPLATES.map((template, index) => (
            <Button
              key={index}
              variant="outline"
              size="sm"
              onClick={() => loadTemplate(template)}
              className="font-mono text-xs hover:neon-glow-cyan"
            >
              <FileCode className="w-3 h-3 mr-1" />
              {template.name}
            </Button>
          ))}
        </div>

        {/* Actions */}
        <div className="flex items-center space-x-2">
          <Button
            onClick={handleCopyCode}
            variant="outline"
            size="sm"
            className="font-mono hover:neon-glow-green"
          >
            <Copy className="w-4 h-4 mr-2" />
            COPY CODE
          </Button>
          <Button
            onClick={handleDownload}
            variant="outline"
            size="sm"
            className="font-mono hover:neon-glow-yellow"
          >
            <Download className="w-4 h-4 mr-2" />
            DOWNLOAD
          </Button>
          {onExport && (
            <Button
              onClick={() => onExport(htmlCode, cssCode, jsCode)}
              className="font-mono"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              EXPORT
            </Button>
          )}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex">
        {/* Code Editor */}
        <div className="w-1/2 border-r border-cyber-border">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
            <TabsList className="bg-cyber-card cyber-glass border-b border-cyber-border rounded-none">
              <TabsTrigger value="html" className="font-mono data-[state=active]:neon-glow-red">
                <Code className="w-4 h-4 mr-2" />
                HTML
              </TabsTrigger>
              <TabsTrigger value="css" className="font-mono data-[state=active]:neon-glow-blue">
                <Palette className="w-4 h-4 mr-2" />
                CSS
              </TabsTrigger>
              <TabsTrigger value="js" className="font-mono data-[state=active]:neon-glow-yellow">
                <Zap className="w-4 h-4 mr-2" />
                JAVASCRIPT
              </TabsTrigger>
            </TabsList>

            <TabsContent value="html" className="flex-1 p-0">
              <Textarea
                value={htmlCode}
                onChange={(e) => setHtmlCode(e.target.value)}
                className="h-full w-full resize-none border-0 rounded-none bg-cyber-card cyber-glass font-mono text-sm"
                placeholder="Enter your HTML code here..."
              />
            </TabsContent>

            <TabsContent value="css" className="flex-1 p-0">
              <Textarea
                value={cssCode}
                onChange={(e) => setCssCode(e.target.value)}
                className="h-full w-full resize-none border-0 rounded-none bg-cyber-card cyber-glass font-mono text-sm"
                placeholder="Enter your CSS styles here..."
              />
            </TabsContent>

            <TabsContent value="js" className="flex-1 p-0">
              <Textarea
                value={jsCode}
                onChange={(e) => setJsCode(e.target.value)}
                className="h-full w-full resize-none border-0 rounded-none bg-cyber-card cyber-glass font-mono text-sm"
                placeholder="Enter your JavaScript code here..."
              />
            </TabsContent>
          </Tabs>
        </div>

        {/* Live Preview */}
        {isPreviewVisible && (
          <div className="w-1/2 bg-white">
            <div className="h-full">
              <div className="p-2 bg-cyber-surface border-b border-cyber-border">
                <Badge variant="outline" className="font-mono neon-text-green">
                  LIVE PREVIEW - {previewMode.toUpperCase()}
                </Badge>
              </div>
              <div className={cn(
                "h-full overflow-auto",
                previewMode === "mobile" ? "max-w-sm mx-auto" : ""
              )}>
                <iframe
                  srcDoc={generatePreview()}
                  className="w-full h-full border-0"
                  title="HTML Preview"
                  sandbox="allow-scripts allow-same-origin"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}