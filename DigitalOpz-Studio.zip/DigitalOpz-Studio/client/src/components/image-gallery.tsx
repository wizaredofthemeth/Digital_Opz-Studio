import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { type GeneratedImage } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Download, 
  Share2, 
  Heart, 
  MoreHorizontal, 
  Copy, 
  Trash2, 
  Eye,
  Clock,
  Zap,
  Sparkles,
  Image as ImageIcon
} from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface ImageGalleryProps {
  images: GeneratedImage[];
  isLoading: boolean;
  viewMode: "grid" | "list";
  emptyMessage: string;
  showPrivateControls?: boolean;
}

export default function ImageGallery({ 
  images, 
  isLoading, 
  viewMode, 
  emptyMessage, 
  showPrivateControls = false 
}: ImageGalleryProps) {
  const { toast } = useToast();
  const [selectedImage, setSelectedImage] = useState<GeneratedImage | null>(null);

  const deleteMutation = useMutation({
    mutationFn: async (imageId: string) => {
      await apiRequest("DELETE", `/api/images/${imageId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/images"] });
      toast({
        title: "Image deleted",
        description: "The image has been removed from your collection.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete the image. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCopyPrompt = (prompt: string) => {
    navigator.clipboard.writeText(prompt);
    toast({
      title: "Copied to clipboard",
      description: "The prompt has been copied to your clipboard.",
    });
  };

  const handleDownload = (image: GeneratedImage) => {
    const link = document.createElement("a");
    link.href = image.imageUrl;
    link.download = `ai-generated-${image.id}.jpg`;
    link.click();
  };

  const handleShare = async (image: GeneratedImage) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `AI Generated Image - ${image.prompt.slice(0, 50)}...`,
          text: image.prompt,
          url: image.imageUrl,
        });
      } catch (error) {
        // Fallback to clipboard
        handleCopyPrompt(image.imageUrl);
      }
    } else {
      handleCopyPrompt(image.imageUrl);
    }
  };

  if (isLoading) {
    return (
      <div className={cn(
        "gap-6",
        viewMode === "grid" 
          ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4" 
          : "space-y-4"
      )}>
        {Array.from({ length: 8 }).map((_, i) => (
          <Card key={i} className="bg-cyber-card cyber-glass border-cyber-border">
            <div className={cn(
              "gradient-cyber animate-cyber-pulse rounded-lg",
              viewMode === "grid" ? "aspect-square" : "h-32"
            )}></div>
            {viewMode === "list" && (
              <CardContent className="p-4">
                <div className="h-4 gradient-cyber animate-cyber-pulse rounded mb-2"></div>
                <div className="h-3 gradient-cyber animate-cyber-pulse rounded w-2/3"></div>
              </CardContent>
            )}
          </Card>
        ))}
      </div>
    );
  }

  if (images.length === 0) {
    return (
      <Card className="bg-dark-card border-dark-border">
        <CardContent className="flex flex-col items-center justify-center py-16">
          <div className="w-20 h-20 bg-gray-800 rounded-full flex items-center justify-center mb-6">
            <ImageIcon className="w-10 h-10 text-gray-600" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">No Images Found</h3>
          <p className="text-gray-400 text-center max-w-md">{emptyMessage}</p>
        </CardContent>
      </Card>
    );
  }

  if (viewMode === "list") {
    return (
      <div className="space-y-4">
        {images.map((image) => (
          <Card key={image.id} className="bg-dark-card border-dark-border">
            <CardContent className="p-0">
              <div className="flex">
                <div className="w-32 h-32 flex-shrink-0">
                  <img
                    src={image.thumbnailUrl || image.imageUrl}
                    alt={image.prompt}
                    className="w-full h-full object-cover rounded-l-lg"
                    onError={(e) => {
                      e.currentTarget.src = "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?w=400";
                    }}
                  />
                </div>
                <div className="flex-1 p-4 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between mb-2">
                      <p className="text-white font-medium line-clamp-2">{image.prompt}</p>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="text-gray-400">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent className="bg-dark-card border-dark-border">
                          <DropdownMenuItem onClick={() => setSelectedImage(image)}>
                            <Eye className="w-4 h-4 mr-2" />
                            View Details
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleCopyPrompt(image.prompt)}>
                            <Copy className="w-4 h-4 mr-2" />
                            Copy Prompt
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleDownload(image)}>
                            <Download className="w-4 h-4 mr-2" />
                            Download
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleShare(image)}>
                            <Share2 className="w-4 h-4 mr-2" />
                            Share
                          </DropdownMenuItem>
                          {showPrivateControls && (
                            <DropdownMenuItem 
                              onClick={() => deleteMutation.mutate(image.id)}
                              className="text-red-400 focus:text-red-400"
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    <div className="flex items-center space-x-3 text-sm text-gray-400">
                      <Badge variant="outline" className="text-xs">
                        {image.model}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {image.style}
                      </Badge>
                      <span>{image.aspectRatio}</span>
                      <span className="flex items-center">
                        <Clock className="w-3 h-3 mr-1" />
                        {image.generationTime}s
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-3">
                    <span className="text-xs text-gray-500">
                      {new Date(image.createdAt!).toLocaleDateString()}
                    </span>
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                        <Heart className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => handleShare(image)} className="text-gray-400 hover:text-white">
                        <Share2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {images.map((image) => (
          <Card key={image.id} className="bg-dark-card border-dark-border group hover:border-primary/50 transition-all duration-300">
            <CardContent className="p-0">
              <div className="relative">
                <img
                  src={image.thumbnailUrl || image.imageUrl}
                  alt={image.prompt}
                  className="w-full aspect-square object-cover rounded-t-lg cursor-pointer"
                  onClick={() => setSelectedImage(image)}
                  onError={(e) => {
                    e.currentTarget.src = "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?w=400";
                  }}
                />
                
                {/* Overlay on hover */}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-t-lg flex items-center justify-center space-x-2">
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => setSelectedImage(image)}
                  >
                    <Eye className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => handleDownload(image)}
                  >
                    <Download className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => handleShare(image)}
                  >
                    <Share2 className="w-4 h-4" />
                  </Button>
                </div>

                {/* Top-right badges */}
                <div className="absolute top-2 right-2 flex space-x-1">
                  <Badge className="bg-black/60 text-white text-xs">
                    {image.aspectRatio}
                  </Badge>
                </div>
              </div>

              {/* Card content */}
              <div className="p-4">
                <p className="text-white font-medium text-sm line-clamp-2 mb-2">
                  {image.prompt}
                </p>
                
                <div className="flex items-center justify-between text-xs text-gray-400 mb-3">
                  <div className="flex items-center space-x-2">
                    <Badge variant="outline" className="text-xs">
                      <Zap className="w-3 h-3 mr-1" />
                      {image.model}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      <Sparkles className="w-3 h-3 mr-1" />
                      {image.style}
                    </Badge>
                  </div>
                  <span className="flex items-center">
                    <Clock className="w-3 h-3 mr-1" />
                    {image.generationTime}s
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">
                    {new Date(image.createdAt!).toLocaleDateString()}
                  </span>
                  
                  <div className="flex items-center space-x-1">
                    <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white p-1 h-auto">
                      <Heart className="w-3 h-3" />
                    </Button>
                    {showPrivateControls && (
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white p-1 h-auto">
                            <MoreHorizontal className="w-3 h-3" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent className="bg-dark-card border-dark-border">
                          <DropdownMenuItem onClick={() => handleCopyPrompt(image.prompt)}>
                            <Copy className="w-4 h-4 mr-2" />
                            Copy Prompt
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            onClick={() => deleteMutation.mutate(image.id)}
                            className="text-red-400 focus:text-red-400"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Image Detail Dialog */}
      {selectedImage && (
        <Dialog open={!!selectedImage} onOpenChange={() => setSelectedImage(null)}>
          <DialogContent className="max-w-4xl bg-dark-surface border-dark-border">
            <DialogHeader>
              <DialogTitle className="text-white">Image Details</DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <img
                  src={selectedImage.imageUrl}
                  alt={selectedImage.prompt}
                  className="w-full rounded-lg"
                  onError={(e) => {
                    e.currentTarget.src = "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?w=600";
                  }}
                />
              </div>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-white mb-2">Prompt</h3>
                  <p className="text-gray-300 text-sm bg-dark-card p-3 rounded-lg border border-dark-border">
                    {selectedImage.prompt}
                  </p>
                </div>
                
                {selectedImage.negativePrompt && (
                  <div>
                    <h3 className="font-semibold text-white mb-2">Negative Prompt</h3>
                    <p className="text-gray-300 text-sm bg-dark-card p-3 rounded-lg border border-dark-border">
                      {selectedImage.negativePrompt}
                    </p>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-400">Model:</span>
                    <p className="text-white font-medium">{selectedImage.model}</p>
                  </div>
                  <div>
                    <span className="text-gray-400">Style:</span>
                    <p className="text-white font-medium">{selectedImage.style}</p>
                  </div>
                  <div>
                    <span className="text-gray-400">Dimensions:</span>
                    <p className="text-white font-medium">{selectedImage.width} x {selectedImage.height}</p>
                  </div>
                  <div>
                    <span className="text-gray-400">Aspect Ratio:</span>
                    <p className="text-white font-medium">{selectedImage.aspectRatio}</p>
                  </div>
                  <div>
                    <span className="text-gray-400">Steps:</span>
                    <p className="text-white font-medium">{selectedImage.steps}</p>
                  </div>
                  <div>
                    <span className="text-gray-400">CFG Scale:</span>
                    <p className="text-white font-medium">{selectedImage.cfgScale}</p>
                  </div>
                  <div>
                    <span className="text-gray-400">Generation Time:</span>
                    <p className="text-white font-medium">{selectedImage.generationTime}s</p>
                  </div>
                  <div>
                    <span className="text-gray-400">Created:</span>
                    <p className="text-white font-medium">
                      {new Date(selectedImage.createdAt!).toLocaleString()}
                    </p>
                  </div>
                </div>

                <div className="flex space-x-2 pt-4">
                  <Button 
                    onClick={() => handleDownload(selectedImage)} 
                    className="flex-1"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => handleCopyPrompt(selectedImage.prompt)}
                    className="flex-1"
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    Copy Prompt
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => handleShare(selectedImage)}
                  >
                    <Share2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}
