import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { type GeneratedImage } from "@shared/schema";
import ImageGallery from "@/components/image-gallery";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Filter, Grid, List, TrendingUp, Clock, Heart } from "lucide-react";

export default function Gallery() {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("newest");
  const [filterModel, setFilterModel] = useState("all");

  // Get public gallery images
  const { data: publicImages = [], isLoading: isLoadingPublic } = useQuery<GeneratedImage[]>({
    queryKey: ["/api/images"],
    queryFn: async () => {
      const res = await fetch("/api/images?limit=50");
      return res.json();
    },
  });

  // Get user's private images
  const { data: userImages = [], isLoading: isLoadingUser } = useQuery<GeneratedImage[]>({
    queryKey: ["/api/user/images"],
    queryFn: async () => {
      const res = await fetch("/api/user/images?limit=50");
      return res.json();
    },
  });

  const filterImages = (images: GeneratedImage[]) => {
    let filtered = images;

    // Filter by search query
    if (searchQuery.trim()) {
      filtered = filtered.filter(img => 
        img.prompt.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Filter by model
    if (filterModel !== "all") {
      filtered = filtered.filter(img => img.model === filterModel);
    }

    // Sort images
    filtered = filtered.sort((a, b) => {
      switch (sortBy) {
        case "newest":
          return new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime();
        case "oldest":
          return new Date(a.createdAt!).getTime() - new Date(b.createdAt!).getTime();
        case "generation-time":
          return (a.generationTime || 0) - (b.generationTime || 0);
        default:
          return 0;
      }
    });

    return filtered;
  };

  return (
    <div className="min-h-screen bg-dark-bg">
      <div className="container mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">AI Image Gallery</h1>
          <p className="text-gray-400">Explore amazing AI-generated artwork from the community</p>
        </div>

        {/* Search and Filter Bar */}
        <Card className="bg-dark-surface border-dark-border mb-8">
          <CardContent className="p-6">
            <div className="flex flex-col lg:flex-row gap-4 items-center">
              {/* Search */}
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search by prompt or description..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-dark-card border-dark-border text-white"
                />
              </div>

              {/* Filters */}
              <div className="flex gap-3 items-center">
                <Select value={filterModel} onValueChange={setFilterModel}>
                  <SelectTrigger className="w-40 bg-dark-card border-dark-border text-white">
                    <Filter className="w-4 h-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-dark-card border-dark-border">
                    <SelectItem value="all">All Models</SelectItem>
                    <SelectItem value="ideogram-3.0">Ideogram 3.0</SelectItem>
                    <SelectItem value="flux-pro">FLUX Pro</SelectItem>
                    <SelectItem value="sdxl">SDXL</SelectItem>
                    <SelectItem value="sdxl-lightning">SDXL Lightning</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-40 bg-dark-card border-dark-border text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-dark-card border-dark-border">
                    <SelectItem value="newest">
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-2" />
                        Newest First
                      </div>
                    </SelectItem>
                    <SelectItem value="oldest">
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-2" />
                        Oldest First
                      </div>
                    </SelectItem>
                    <SelectItem value="generation-time">
                      <div className="flex items-center">
                        <TrendingUp className="w-4 h-4 mr-2" />
                        Generation Time
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>

                {/* View Mode Toggle */}
                <div className="flex bg-dark-card border border-dark-border rounded-lg p-1">
                  <Button
                    variant={viewMode === "grid" ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setViewMode("grid")}
                    className="px-3"
                  >
                    <Grid className="w-4 h-4" />
                  </Button>
                  <Button
                    variant={viewMode === "list" ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setViewMode("list")}
                    className="px-3"
                  >
                    <List className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Gallery Tabs */}
        <Tabs defaultValue="public" className="w-full">
          <TabsList className="mb-6 bg-dark-surface border border-dark-border">
            <TabsTrigger value="public" className="data-[state=active]:bg-primary flex items-center">
              <TrendingUp className="w-4 h-4 mr-2" />
              Public Gallery ({publicImages.length})
            </TabsTrigger>
            <TabsTrigger value="private" className="data-[state=active]:bg-primary flex items-center">
              <Heart className="w-4 h-4 mr-2" />
              My Creations ({userImages.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="public">
            <ImageGallery
              images={filterImages(publicImages)}
              isLoading={isLoadingPublic}
              viewMode={viewMode}
              emptyMessage="No public images found matching your criteria"
            />
          </TabsContent>

          <TabsContent value="private">
            <ImageGallery
              images={filterImages(userImages)}
              isLoading={isLoadingUser}
              viewMode={viewMode}
              emptyMessage="You haven't generated any images yet. Start creating!"
              showPrivateControls
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
