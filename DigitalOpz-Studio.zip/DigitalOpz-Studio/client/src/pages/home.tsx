import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import GenerationControls from "@/components/generation-controls";
import GenerationProgress from "@/components/generation-progress";
import ImageCard from "@/components/image-card";
import AdvancedTools from "@/components/advanced-tools";
import { type GenerateImageRequest, type User, type GenerationJob, type GeneratedImage } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Crown, Sparkles, Zap } from "lucide-react";

export default function Home() {
  const [activeJob, setActiveJob] = useState<string | null>(null);
  const [recentImages, setRecentImages] = useState<GeneratedImage[]>([]);

  // Get current user
  const { data: user } = useQuery<User>({
    queryKey: ["/api/user/current"],
  });

  // Get user's recent images
  const { data: userImages = [] } = useQuery<GeneratedImage[]>({
    queryKey: ["/api/user/images"],
    queryFn: async () => {
      const res = await fetch("/api/user/images?limit=8");
      return res.json();
    },
  });

  // Generation mutation
  const generateMutation = useMutation({
    mutationFn: async (request: GenerateImageRequest) => {
      const res = await apiRequest("POST", "/api/generate", request);
      return res.json();
    },
    onSuccess: (data) => {
      setActiveJob(data.jobId);
    },
  });

  const handleGenerate = (request: GenerateImageRequest) => {
    generateMutation.mutate(request);
  };

  const handleJobComplete = (generatedImage: GeneratedImage) => {
    setRecentImages(prev => [generatedImage, ...prev.slice(0, 7)]);
    setActiveJob(null);
  };

  const handleApplyEffect = (effect: any) => {
    console.log('Applying effect:', effect);
    // TODO: Implement effect application logic
  };

  return (
    <div className="flex h-screen overflow-hidden bg-cyber-bg cyber-grid relative">
      {/* Cyberpunk background effects */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 left-1/4 w-px h-full bg-gradient-to-b from-transparent via-cyber-neon-cyan to-transparent opacity-20 animate-pulse"></div>
        <div className="absolute top-0 right-1/3 w-px h-full bg-gradient-to-b from-transparent via-cyber-neon-pink to-transparent opacity-20 animate-pulse" style={{animationDelay: '1s'}}></div>
        <div className="absolute top-0 left-3/4 w-px h-full bg-gradient-to-b from-transparent via-cyber-neon-yellow to-transparent opacity-20 animate-pulse" style={{animationDelay: '2s'}}></div>
      </div>

      {/* Left Sidebar - Controls */}
      <div className="w-80 bg-cyber-surface cyber-glass border-r border-cyber-border flex flex-col relative z-10">
        <GenerationControls
          onGenerate={handleGenerate}
          isGenerating={generateMutation.isPending || !!activeJob}
        />
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden relative z-10">
        {/* Header Stats */}
        <div className="bg-cyber-surface cyber-glass border-b border-cyber-border px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold neon-text-cyan font-mono tracking-wider mb-1 animate-neon-flicker">DIGITAL-OPZ STUDIO</h1>
              <p className="text-sm text-muted-foreground font-mono">UNLIMITED AI IMAGE GENERATION - COMPLETELY FREE</p>
            </div>
            
            {user && (
              <div className="flex items-center space-x-4">
                <div className="cyber-glass rounded px-4 py-2 flex items-center space-x-2 neon-glow-green">
                  <Sparkles className="w-4 h-4 text-cyber-neon-green animate-neon-flicker" />
                  <span className="text-sm font-mono neon-text-green">
                    UNLIMITED ACCESS
                  </span>
                </div>
                <div className="cyber-glass rounded px-4 py-2 flex items-center space-x-2 neon-glow-cyan">
                  <Zap className="w-4 h-4 text-cyber-neon-cyan animate-neon-flicker" />
                  <span className="text-sm font-mono neon-text-cyan">
                    ∞ CREDITS
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-hidden splash-neon">
          {activeJob ? (
            <div className="h-full flex items-center justify-center smoke-bg">
              <GenerationProgress 
                jobId={activeJob} 
                onComplete={handleJobComplete}
              />
            </div>
          ) : (
            <div className="h-full overflow-y-auto p-6 gringy-texture">
              <Tabs defaultValue="recent" className="w-full">
                <TabsList className="mb-6 bg-cyber-card cyber-glass border border-cyber-border neon-glow-cyan">
                  <TabsTrigger value="recent" className="data-[state=active]:gradient-cyber data-[state=active]:text-black data-[state=active]:animate-rainbow-shift font-mono tracking-wide transition-all duration-300">
                    <Zap className="w-4 h-4 mr-2 animate-neon-flicker" />
                    RECENT GENERATIONS
                  </TabsTrigger>
                  <TabsTrigger value="featured" className="data-[state=active]:gradient-cyber data-[state=active]:text-black data-[state=active]:animate-rainbow-shift font-mono tracking-wide transition-all duration-300">
                    <Sparkles className="w-4 h-4 mr-2 animate-neon-flicker" />
                    FEATURED GALLERY
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="recent">
                  {recentImages.length > 0 || userImages.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                      {[...recentImages, ...userImages].slice(0, 8).map((image, index) => (
                        <ImageCard key={`${image.id}-${index}`} image={image} />
                      ))}
                    </div>
                  ) : (
                    <Card className="bg-cyber-card cyber-glass border-cyber-border neon-glow-yellow">
                      <CardContent className="flex flex-col items-center justify-center py-12 smoke-bg">
                        <div className="w-16 h-16 gradient-cyber rounded-full flex items-center justify-center mb-4 animate-cyber-pulse">
                          <Sparkles className="w-8 h-8 text-black animate-neon-flicker" />
                        </div>
                        <h3 className="text-lg font-bold font-mono neon-text-yellow mb-2 animate-neon-rainbow-glow">START CREATING</h3>
                        <p className="text-gray-400 text-center max-w-md">
                          Enter a prompt in the controls panel to generate your first AI image. 
                          Your creations will appear here.
                        </p>
                      </CardContent>
                    </Card>
                  )}
                </TabsContent>

                <TabsContent value="featured">
                  <FeaturedGallery />
                </TabsContent>
              </Tabs>
            </div>
          )}
        </div>
      </div>
      
      {/* Advanced Tools Panel */}
      <AdvancedTools onApplyEffect={handleApplyEffect} />
    </div>
  );
}

function FeaturedGallery() {
  const { data: featuredImages = [], isLoading } = useQuery<GeneratedImage[]>({
    queryKey: ["/api/images"],
    queryFn: async () => {
      const res = await fetch("/api/images?limit=16");
      return res.json();
    },
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {Array.from({ length: 8 }).map((_, i) => (
          <Card key={i} className="bg-dark-card border-dark-border">
            <div className="aspect-square bg-dark-bg animate-pulse rounded-lg"></div>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {featuredImages.map((image) => (
        <ImageCard key={image.id} image={image} />
      ))}
    </div>
  );
}
